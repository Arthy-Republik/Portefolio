# Exercice

  1) Créer un base de données **async_await**

  2) Créer la tables *USER* qui contient les champs suivants :
    * ID
    * NAME
    * PHONE
    * EMAIL
    * ADDRESS
  
  3) Sur notre HTML
    1) Créer un formulaire d'ajout d'utilisateur
    2) Créer un tableau vierge

  4) A la validation du formulaire, on ajoute l'utilisateur dans notre BDD

  5) On génère l'affichage  dynamiquement sans recharger notre page !
    * Insérrer les infos dans notre tableau préalablement créé.